package Pac1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class Validate_Topgearpage1 {
	public static void main(String[] args) throws Exception 
	{
						
	System.setProperty("webdriver.firefox.marionette","C:\\Users\\anitg\\Desktop\\sel\\geckodriver-v0.14.0-win64\\geckodriver-v0.16.1-win64 (1)\\geckodriver.exe");
	WebDriver driver = new FirefoxDriver();
	Actions Act = new Actions(driver);
	driver.manage().window().maximize();
	
	// Launching URL
	driver.get("https://topgear-app.wipro.com/trainings-online");
	
	//verifying the URL
	if (driver.getTitle().equals("TopGear | Engage | Be Future Ready"))
	{

		System.out.println("Verified Title and Title is   " + driver.getTitle());
	}
else{
		System.out.println("Failed to Verify Title");
	}

	driver.findElement(By.id("edit-name")).sendKeys("anitg");
	driver.findElement(By.id("edit-pass")).sendKeys("password");
	driver.findElement(By.id("edit-submit")).click();
	driver.findElement(By.xpath("html/body/div[2]/div[1]/div[1]/div[1]/div/header/div[2]/div/div/div/div/div/div[3]/a/img")).click();
	driver.close();
}
}

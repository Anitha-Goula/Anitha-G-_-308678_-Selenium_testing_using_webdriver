package Pac1;
import java.awt.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebDriver;


public class Counting {
	
	public static void main(String[] args)
		{
		
		System.setProperty("webdriver.firefox.marionette","C:\\Users\\anitg\\Desktop\\sel\\geckodriver-v0.14.0-win64\\geckodriver-v0.16.1-win64 (1)\\geckodriver.exe");

		WebDriver driver = new FirefoxDriver();
		
		Actions Act = new Actions(driver);
		
		driver.get("https://www.google.co.in");
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
		driver.manage().window().maximize();
		
		WebElement E = driver.findElement(By.xpath("//*[@id='gbw']/div/div/div[2]/div[4]/div/a"));
		
		Act.click(E).build().perform();		
		
		java.util.List<WebElement> link = driver.findElements(By.tagName("a")); 

		System.out.println("The number of links in a page is.... " + link.size());

		java.util.List<WebElement> buttons1= driver.findElements(By.tagName("button"));
	
		System.out.println("total number of buttons" + buttons1.size());

		java.util.List images1=driver.findElements(By.tagName("img"));
	
		System.out.println("total number of images" + images1.size());
		
		driver.close();
	}

	}




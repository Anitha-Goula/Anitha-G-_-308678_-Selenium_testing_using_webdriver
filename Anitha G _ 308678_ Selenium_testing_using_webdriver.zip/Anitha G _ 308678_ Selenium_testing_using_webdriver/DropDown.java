package Pac1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class dp3 {
	public static void main(String args[])
	{
	System.setProperty("webdriver.firefox.marionette","C:\\Users\\anitg\\Desktop\\sel\\geckodriver-v0.14.0-win64\\geckodriver-v0.16.1-win64 (1)\\geckodriver.exe");
	
	WebDriver driver = new FirefoxDriver();
	
	Actions Act = new Actions(driver);
		
	driver.manage().window().maximize();
	
	// Launching URL
	driver.get("http://www.webmath.com/");
	
	WebElement E1 = driver.findElement(By.xpath("html/body/div[1]/div[2]/div[2]/div[1]/div[2]/div[2]/div[1]/div/div[3]/div/div[1]/div[1]/div/div[4]/form/div/select"));
    
	Select sel = new Select(E1);
    
    System.out.println("The 1st option is .." + sel.getFirstSelectedOption().getText());
    
    //sel.selectByIndex(7);
    
    sel.selectByValue("diff.html");
    
    driver.close();
    
	}
}

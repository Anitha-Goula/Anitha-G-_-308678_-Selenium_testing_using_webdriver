	package Pac1;
	import java.awt.List;
	import org.openqa.selenium.By;
	import org.openqa.selenium.Keys;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.firefox.FirefoxDriver;
	import org.openqa.selenium.interactions.Actions;

	public class date1 {
	
	public static void main(String[] args) throws Exception
	{

	System.setProperty("webdriver.firefox.marionette","C:\\Users\\anitg\\Desktop\\sel\\geckodriver-v0.14.0-win64\\geckodriver-v0.16.1-win64 (1)\\geckodriver.exe");

	FirefoxDriver driver=new FirefoxDriver();

	Actions Act = new Actions(driver);

	driver.get("https://topgear-app.wipro.com/trainings-online");

	driver.manage().window().maximize();		
		
	driver.findElementById("edit-name").sendKeys("anitg");
	
	driver.findElementById("edit-pass").sendKeys("password");
	
	driver.findElementById("edit-submit").click();
	
	WebElement E = driver.findElement(By.xpath("html/body/div[2]/div[1]/div[2]/div/div/nav/div/div/ul/li[3]/a"));
	
	Act.moveToElement(E).perform();
	
	E.click();
	
	java.util.List<WebElement> date=driver.findElements(By.id("edit-field-oa-date-value-1-value-datepicker-popup-0"));
	
	  for(WebElement dp:date)
		{
		if(dp.getText().equals("10"))
			{
			dp.click();
			break;
			}
		}
	driver.findElements(By.id("edit-field-oa-date-value-2-value-datepicker-popup-0"));
	for(WebElement dpe:date)
		{
		if(dpe.getText().equals("30"))
			{
			dpe.click();
			break;
			}
		}
	
    driver.close();
	}

	}

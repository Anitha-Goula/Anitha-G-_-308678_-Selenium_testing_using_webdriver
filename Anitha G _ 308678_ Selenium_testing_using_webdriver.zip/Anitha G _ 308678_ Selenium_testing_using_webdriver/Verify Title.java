package Pac1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
public class VerifyTitle 
{
	
	public static void main(String[] args) throws Exception 
	{
						
	System.setProperty("webdriver.firefox.marionette","C:\\Users\\anitg\\Desktop\\sel\\geckodriver-v0.14.0-win64\\geckodriver-v0.16.1-win64 (1)\\geckodriver.exe");
	WebDriver driver = new FirefoxDriver();
	Actions Act = new Actions(driver);
	driver.manage().window().maximize();
	
	//Open URL
	driver.get("https://www.google.com");
	WebElement E = driver.findElement(By.xpath("//*[@id='gbw']/div/div/div[2]/div[4]/div/a"));
        Act.click(E).build().perform();

    // Verify Title
	if (driver.getTitle().equals("Google"))
		{

			System.out.println("Verified Title and Title is    " + driver.getTitle());
		}
	else{
			System.out.println("Failed to Verify Title");

		}
	
	driver.navigate().refresh();

	//Sending "Selenium automation" text in google search box
	driver.findElement(By.xpath("html/body/div[1]/div[3]/form/div[2]/div[2]/div[1]/div[1]/div[3]/div/div/div[3]")).sendKeys("Selenium automation");
	driver.close();
	}
}


